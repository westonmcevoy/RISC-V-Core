# riscv32i_cycle_accurate
Starting project to implement a 5-stage RISCV32I processor
